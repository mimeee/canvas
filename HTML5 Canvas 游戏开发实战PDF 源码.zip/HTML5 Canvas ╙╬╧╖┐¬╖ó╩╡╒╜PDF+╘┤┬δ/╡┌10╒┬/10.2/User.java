
public class User {
	private String name = "";
	private String color = "";
	
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	private int x = 0;
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	private int y = 0;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
